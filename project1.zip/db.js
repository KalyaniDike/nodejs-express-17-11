var mongoose = require("mongoose");

async function dbconnect() {
  var connections = await mongoose.connect(
    "mongodb://127.0.0.1:27017/userdetails"
  );
  return connections;
}

module.exports = dbconnect;
