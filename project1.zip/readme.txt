npm init -y

$ npm install express

C:\Program Files\MongoDB\Server\4.2\bin

use userdetails

show dbs

db

db.createCollection('users');

show collections

1)insert()
2)insertOne()
3)insertMany()

db.users.insert([{ "name" :"kalyani","age":20,"place":"vaijapur"},
{"name" :"krutika","age":18,"place":"nashik"},
{"name" :"shweta","age":22,"place":"pune"}]);


//for products
db.products.insert([{ "name" :"kalyani","price":20000,"discount":"2000"},
{"name" :"krutika","price":18000,"discount":"1500"},
{"name" :"shweta","price":22000,"discount":"2200"}]);






db.users.find();

db.users.find({"place":"pune"})

db.users.remove({"place":"pune"})

db.users.update({
    "place":"mumbai"
},
{$set:{
    "name":"sahyu",
    "age":24

}
})

//products


db.products.update({
    "name":"kalyani"
},
{$set:{
    "name":"sahyu",
    "discount":2400

}
})









//revision

node -v
npm -v[yarn,bower,..]
project2/
npm init -y --> package.json
create index.js
run index.js?npn start
npm i express mongoose mysql--node_modules
will be created,package.json will be created  
